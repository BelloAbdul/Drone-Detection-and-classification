#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 
# Copyright 2018 gr-MachineLearning author.
# 
# This is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
# 
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this software; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street,
# Boston, MA 02110-1301, USA.
# 

import numpy
from gnuradio import gr
import pandas as pd
import scipy
import pickle

from sklearn.linear_model import LogisticRegression
from sklearn import linear_model
from sklearn import tree
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB

class ML_Training(gr.basic_block):
    """
    docstring for block ML_Training
    """
    def __init__(self, data_path, model_name):
        gr.basic_block.__init__(self,
            name="ML_Training",
            in_sig=None,
            out_sig=None)
        self.data_path = data_path
        self.model_name = model_name
        self.train(self.data_path, self.model_name)
    """
    def forecast(self, noutput_items, ninput_items_required):
        #setup size of input_items[i] for work call
        for i in range(len(ninput_items_required)):
            ninput_items_required[i] = noutput_items

    def general_work(self, input_items, output_items):
        output_items[0][:] = input_items[0]
        consume(0, len(input_items[0]))
        #self.consume_each(len(input_items[0]))
        return len(output_items[0])
    """
    def train(self, path, model):
        data = pd.read_csv(path)
        x_train=data.values[:, 1:data.shape[1]]
	y_train=data.values[:, 0]
	
	if model == "LinearReg":
		c_model = linear_model.LinearRegression()
		c_model.fit(x_train, y_train)
		# save the model to disk
    		filename = '/home/cssdr/ML_Models/Linear_model.sav'
    		pickle.dump(c_model, open(filename, 'wb'))
	elif model == "LR":
		c_model = LogisticRegression()
		c_model.fit(x_train, y_train)
		# save the model to disk
    		filename = '/home/cssdr/ML_Models/LR_model.sav'
    		pickle.dump(c_model, open(filename, 'wb'))
        elif model == "DT":
		c_model = tree.DecisionTreeClassifier(criterion='gini')
		c_model.fit(x_train, y_train)
		# save the model to disk
    		filename = '/home/cssdr/ML_Models/DT_model.sav'
    		pickle.dump(c_model, open(filename, 'wb'))
	elif model == "SVM":
		c_model = svm.SVC(kernel='linear', C=1, gamma=1)
		c_model.fit(x_train, y_train)
		# save the model to disk
    		filename = '/home/cssdr/ML_Models/SVM_model.sav'
    		pickle.dump(c_model, open(filename, 'wb'))
	elif model == "NB":
		c_model = GaussianNB()
		c_model.fit(x_train, y_train)
		# save the model to disk
    		filename = '/home/cssdr/ML_Models/NB_model.sav'
    		pickle.dump(c_model, open(filename, 'wb'))
	elif model == "RF":
		c_model = RandomForestClassifier()
		c_model.fit(x_train, y_train)
		# save the model to disk
    		filename = '/home/cssdr/ML_Models/RF_model.sav'
    		pickle.dump(c_model, open(filename, 'wb'))
	else:
		print("Error!! Choose a training model")
