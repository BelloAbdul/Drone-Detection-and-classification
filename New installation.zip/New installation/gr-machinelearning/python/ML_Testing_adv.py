#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 
# Copyright 2018 gr-MachineLearning author.
# 
# This is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
# 
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this software; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street,
# Boston, MA 02110-1301, USA.
# 

import numpy as np
import pmt
from gnuradio import gr
import pickle
import pandas as pd

class ML_Testing_adv(gr.basic_block):
    """
    docstring for block ML_Testing_adv
    """
    def __init__(self, model):
        gr.basic_block.__init__(self,
            name="ML_Testing_adv",
            in_sig=[],
            out_sig=[])
	self.model_name = model
	self.message_port_register_in(pmt.intern('in'))
	self.set_msg_handler(pmt.intern('in'), self.handle_msg)

    def handle_msg(self, msg_pmt):
	elems = list()
        # collect data, convert to Python format:
	for i in range(pmt.length(msg_pmt)):
		elem = pmt.tuple_ref(msg_pmt, i)
		elems.append(pmt.to_python(elem)[1])		
	
	x_test = np.array(elems).reshape(1, -1)
	# load the model from disk
	filename = '/home/user/cssdr/ML_Models/'+ self.model_name
	loaded_model = pickle.load(open(filename, 'rb'))
	predicted = loaded_model.predict(x_test)
	#result = loaded_model.score(x_test, y_test)
	print('The predicted class is %s' %predicted)
        








